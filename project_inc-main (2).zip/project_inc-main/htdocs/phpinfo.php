<?php 

$value = 100.5;

echo $value . "<br>";

echo "Philippine Standard Monetary Value: Php " . $value * (string) 5;